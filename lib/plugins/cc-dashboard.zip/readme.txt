=== CC Dashboard ===
Contributors: Xuwei Hu, Jurre Hengstman
Tags: dashboard, catapult, hellendoorn, cc-dashboard, cc
Donate link: https://www.catapult.nl
Requires at least: 4.3.0
Tested up to: 4.9.8
Stable tag: trunk

CC-dahsboard plugin voor sites gemaakt door Catapult Creeert.

== Description ==
Dashboard thema plugin gemaakt voor websites gemaakt door Catapult.

== Installation ==
Upload the .zip folder into the plugins section of wordpress.

== Changelog ==
1.6 Updater added. CC-dashboard added auto updater.
1.7.6 Nieuwe stijl CC-dashboard
1.7.7 Cookiemelding kan nu worden ingeschakeld via themaopties. Googlecode section uitgebreid met Tagmanager.
1.7.8 Bugfix headers already sent by (output started at cc-dashboard.php:1)
1.7.9 Bugfix cookiemelding on cache.
1.8.0 Aanpassing cookiemelding + stijl
1.8.1 Fix vertaling melding, kleur Wordfence en logo dashboard links bovenin.
1.8.2 Fix pad naar logo
2.0.0 Versie 2 met uitgebreide cookiemelding. Let op: Themabestanden moeten aangepast worden voor volledige werking!
2.1.0 Cookiemelding aangepast ivm cache. PHP aangepast naar JS.